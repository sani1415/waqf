pRTLPCB(0,[{"t":"c","d":{"t":"r","d":"s-usc1f-nss-2543.firebaseio.com"}}]);
pLPCommand('close');
